<!DOCTYPE html>
<html>
<head>
	<title>Sistem Peminjaman Registrasi</title>
</head>
<body>
	<form>
	<label for="username">Username : </label>
	<input type="text" size="15" id="username" name="username"/>
	<br>
	<label for="password">Password : </label>
	<input type="password" size="15" id="password" name="password"/>
	<br>
	<input type="submit" value="Login"/>
	</form>
</body>
</html>