<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pinjaman extends CI_Controller {
	public function index()
	{
		$this->load->database();
		$this->load->helper('url');
		$this->load->view('login_pinjaman_view');
		/*if($this->session->user)
		{

		}*/
	}

	public function login()
	{
		$this->load->helper(array('form'));
		$this->load->view('login_pinjaman_view');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->model('PinjamanModel');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$result = $this->PinjamanModel->login($username, $password);
		if($result)
		{
			$sess_array = array();
			foreach($result as $row)
			{
				$sess_array = array(
					'id' => $row->id,
					'username' => $row->username);
				$this->session->set_userdata('logged_in', $sess_array);
			}
			redirect('Pinjaman', 'index');
		}
		else
		{
			$data['login_msg'] = "error username or password";
			$this->load->view('login_pinjaman_view', $data);
		}

		
	}

}
?>