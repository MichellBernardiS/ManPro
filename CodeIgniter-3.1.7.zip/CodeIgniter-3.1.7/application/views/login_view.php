<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
<h1>Simple Login with CodeIgniter</h1>
<form action="<?php echo site_url('login/dologin'); ?>" method="POST">
<label for="username">Username : </label>
<input type="text" size="20" id="username" name="username"/><br /><br />
<label for="password">Password : </label>
<input type="password" size="20" id="password" name="password" /><br /><br />
<input type="submit" value="Login"/>
</form>
</body>
</html>