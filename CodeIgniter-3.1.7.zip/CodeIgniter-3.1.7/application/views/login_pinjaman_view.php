<!DOCTYPE html>
<html>
<head>
	<title>Sistem Peminjaman Registrasi</title>
</head>
<body>
	<form action="<?php echo site_url('Pinjaman/login'); ?>" method="POST">
	<label for="username">Username : </label> <input type="text" size="15" id="username" name="username" value="<?php echo set_value('username'); ?>"/>
	<br>
	<label for="password">Password : </label> <input type="password" size="15" id="password" name="password" value="<?php echo set_value('password'); ?>"/>
	<br>
	<input type="submit" name="login" value="Login"/>
	</form>
	<form action="<?php echo site_url('Pinjaman/signup'); ?>">
	<input type="submit" value="Sign Up"/>
	</form>
</body>
</html>