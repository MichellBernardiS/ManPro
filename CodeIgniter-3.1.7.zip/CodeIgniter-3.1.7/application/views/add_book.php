<!DOCTYPE html>
<html>
<head>
	<title>Add Book</title>
</head>
<body>
	<table>
		<thead>
		</thead>
		<tbody>
			<?php echo form_open('book/add_book'); ?>
			<h1>Insert book</h1>
			<?php if(isset($message)) { ?> 
			<center>Data inserted successfully</center> <?php } ?>
			<tr>
				<?php echo form_label('ISBN :');?>
				<?php echo form_input(array('id' => 'isbn', 'name' => 'isbn')); ?><br />
			</tr>
			<tr>
				<?php echo form_label('Title :');?>
				<?php echo form_input(array('id' => 'title', 'name' => 'title')); ?><br />
			</tr>
			<tr>
				<?php echo form_label('Author :');?>
				<?php echo form_input(array('id' => 'author', 'name' => 'author')); ?><br />
			</tr>
			<tr>
				<?php echo form_label('Publisher :');?>
				<?php echo form_input(array('id' => 'publisher', 'name' => 'publisher')); ?><br />
			</tr>
			<tr>
				<?php echo form_label('Year :');?>
				<?php echo form_input(array('id' => 'year', 'name' => 'year')); ?> <br />
			</tr>
			<tr>
				<?php echo form_label('ImageSmall :');?>
				<?php echo form_input(array('id' => 'imgsmall', 'name' => 'imagesmall')); ?><br />
			</tr>
			<tr>
				<?php echo form_label('ImageMedium :');?>
				<?php echo form_input(array('id' => 'imgmedium', 'name' => 'imagemedium')); ?><br />
			</tr>
			<tr>
				<?php echo form_label('ImageLarge :');?>
				<?php echo form_input(array('id' => 'imglarge', 'name' => 'imagelarge')); ?><br />
			</tr>
			<tr>
				<?php echo form_submit(array('id' => 'submit', 'value' => 'Submit')); ?>
				<?php echo form_close(); ?>
			</tr>
		</tbody>
	</table>
</body>
</html>		