<!DOCTYPE html>
<html>
<head>
	<title>Sign Up Sistem Peminjaman Registrasi</title>
</head>
<body>
	<form action="<?php echo site_url('Pinjaman/signup'); ?>" method="POST">
		<label for="username">Username : </label> <input type="text" size="15" id="username" name="username" value="<?php echo set_value('username'); ?>"/>
		<br>
		<label for="fullname">Fullname : </label> <input type="text" size="15" id="fullname" name="fullname" value="<?php echo set_value('fullname'); ?>"/>
		<br>
		<label for="email">Email : </label> <input type="text" size="15" id="email" name="email" value="<?php echo set_value('email'); ?>"/>
		<br>
		<label for="password">Password : </label> <input type="password" size="15" id="password" name="password" value="<?php echo set_value('password'); ?>"/>
		<br>
		<label for="repassword">Retype Password : </label> <input type="password" size="15" id="repassword" name="repassword" value="<?php echo set_value('repassword'); ?>"/>
		<br>
		<input type="submit" name="register" value="Register"/> 
	</form>
	<form action="<?php echo site_url('Pinjaman/login'); ?>">
		<input type="submit" value="Cancel"/>
	</form>
</body>
</html>