<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pinjaman extends CI_Controller {
	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data = array();
		if($this->session->userdata('isUserLoggedIn'))
		{
			$data['user']=$this->PinjamanModel->getRows(array('id' => $this->session->userdata('userId')));
			$this->load->view('pinjaman_view', $data);
		}
		else
		{
			redirect('Pinjaman/login');
		}
	}

	public function signup()
	{
		$this->load->model('PinjamanModel');
		$this->load->library('form_validation');

		if($this->input->post('register'))
		{
			$this->form_validation->set_rules('username', 'Username', 'required|min_length[4]');
			$this->form_validation->set_rules('fullname', 'Fullname', 'required|min_length[6]');
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('password', 'Password', 'required|callback_valid_password');
			$this->form_validation->set_rules('repassword', 'RePassword', 'required|matches[password]');

			$username = $this->input->post('username');
			$fullname = $this->input->post('fullname');
			$email = $this->input->post('email');
			$password = hash('sha256', $this->input->post('password'));

			$data = array(
				'id'=> null,
				'username'=> $username,
				'fullname'=> $fullname, 
				'email'=> $email, 
				'password'=> $password
			);

			if(isset($data) && $this->form_validation->run() == true)
			{
				$insert = $this->PinjamanModel->signup($data);
				redirect('Pinjaman/login');
			}
			else
			{
				echo validation_errors();
			}
		}

		$this->load->helper('form');
		$this->load->view('signup_pinjaman_view');

	}

	public function login()
	{
		$this->load->model('PinjamanModel');
		$this->load->library('session');
		$this->load->library('form_validation');

		if($this->input->post('login'))
		{
			$username = $this->input->post('username');
			$password = hash('sha256', $this->input->post('password'));
		
			$validate = $this->form_validation->run();
			$result = $this->PinjamanModel->login($username, $password);
			
			if($result && $validate == true)
			{
				$sess_array = array();
				foreach($result as $row)
				{
					$sess_array = array(
						'id' => $row->id,
						'username' => $row->username);
					$this->session->set_userdata('logged_in', $sess_array);
				}
				redirect('Pinjaman/index');
			}
			else if($result && $validate == false)
			{
				echo validation_errors();
				// $err = $err. '<p>Username atau password salah</p>'. PHP_EOL;
				// $data['err'] = $err;
				// echo $data['err'];
			}
		}
		$this->load->view('login_pinjaman_view');
	}

	public function logout()
	{
		$this->session->unset_userdata('isUserLoggedIn');
		$this->session->unset_userdata('userId');
		$this->session->session_destroy();
		redirect('Pinjaman/login');
	}

	public function registrasi()
	{
		$this->load->view('pengajuan_pinjaman_view');
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->model('PinjamanModel');
		$this->load->library('form_validation');

	}

	public function valid_password($password)
	{
		//credited to https://forum.codeigniter.com/thread-66889-post-339273.html
		$password = trim($password);
		$regex_lowercase = '/[a-z]/';
		$regex_uppercase = '/[A-Z]/';
		$regex_number = '/[0-9]/';
		$regex_special = '/[!@#$%^&*()\-_=+{};:,<.>§`~]/';

		if(empty($password))
		{
			$this->form_validation->set_message('valid_password', 'The {field} field is required');
			return FALSE;
		}
		
		if(preg_match_all($regex_lowercase, $password) < 1)
		{
			$this->form_validation->set_message('valid_password', 'The {field} field must be at least one lowercase letter.');
			return FALSE;
		}

		if(preg_match_all($regex_uppercase, $password) < 1 )
		{
			$this->form_validation->set_message('valid_password', 'The {field} field must be at least one uppercase letter.');
			return FALSE;
		}

		if(preg_match_all($regex_number, $password) < 1)
		{
			$this->form_validation->set_message('valid_password', 'The {field} field must be at least one number.');
			return FALSE;
		}

		if (preg_match_all($regex_special, $password) < 1)
        {
            $this->form_validation->set_message('valid_password', 'The {field} field must have at least one special character.' . ' ' . htmlentities('!@#$%^&*()\-_=+{};:,<.>§`~]'));
            return FALSE;
        }

        if (strlen($password) < 6)
        {
            $this->form_validation->set_message('valid_password', 'The {field} field must be at least 6 characters in length.');
            return FALSE;
        }

        return TRUE;
	}
}
?>