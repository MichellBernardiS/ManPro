<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book extends CI_Controller {
	
	/*public function __construct()
        {
                parent::__construct();
                $this->load->helper('url');
                // Your own constructor code
        		if($this->session->userdata('logged_in') )
        		{
        			redirect('Book', 'index');
        		}
        		else
        		{
        			redirect('login', 'index');
        		}
        }*/

	public function index()
	{
		//0.apakah ini sedang pencarian 
		$this->load->model('Bookmodel');
		$searchtext = $this->input->get('searchtext');
		if($searchtext == NULL){
		//1. ambil data dari database		
		$data['books'] = $this->Bookmodel->get_all_books();
		//2. kirim data ke view
	}
	else{
		//1.ambil hasil pencarian
		$data['books'] = $this->Bookmodel->search($searchtext);
		//2.kirim hasil ke view
	}
	$this->load->view('book_index_view', $data);
	}

	public function add_book()
	{
			$this->load->model('Bookmodel');
			if(isset($data))
			{
				$this->Bookmodel->add_book($data);
				$data['message'] = 'Data inserted successfully';
			}
			$isbn = $this->input->post('isbn');
			$title = $this->input->post('title');
			$author = $this->input->post('author');
			$year = $this->input->post('year');
			$publisher = $this->input->post('publisher');
			$imagesmall = $this->input->post('imagesmall');
			$imagemedium = $this->input->post('imagemedium');
			$imagelarge = $this->input->post('imagelarge');

			$data = array(
				'isbn'=>$isbn,'title'=>$title,
				'author'=>$author,'year'=>$year,
				'publisher'=>$publisher,
				'imagesmall'=>$imagesmall,
				'imagemedium'=>$imagemedium,
				'imagelarge'=>$imagelarge
				);

			$this->load->helper('form');
			$this->load->view('add_book');
		
	}
}