<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bookmodel extends CI_Model {
	public function get_all_books()
	{
		$this->load->database();
		$books = $this->db->get('bxbooks');
		return $books;

		//atau return $this->db->get('bxbooks');
	}

	public function search($searchtext){
		$this->load->database();
		$searchtext = '%' . $searchtext . '%' ;
		$sql = 'SELECT * FROM bxbooks WHERE isbn like ? OR title like ? OR author like ? OR publisher like ? OR year like ?';
		$books = $this->db->query($sql, array($searchtext,$searchtext,$searchtext,$searchtext,$searchtext));
		return $books;
	}

	public function add_book($data)
	{
		$this->load->database();
		$this->load->library('session');
		if($this->session->has_userdata('sess_array'))
		{
			$sql = mysqli_query("INSERT INTO bxbooks VALUES ('$data')");
			$hasil = mysqli_query($sql);

			$data['message'] = 'Data inserted successfully';

			echo $data['message'];
			//$this->db->insert('bxbooks', $data);	
		}
		
		else
		{
			$books = $this->db->get('bxbooks');
			return $books;
		}
	}
}