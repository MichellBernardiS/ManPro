<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usermodel extends CI_Model {
	public function checkLogin($username, $password)
	{
		$this->load->database();
		$this->db->select('id, username, password');
		$this->db->from('users');
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$this->db->limit(1);
		$query = $this->db->get();

		if($query->num_rows() == 1)
			return $query->result();
		return false;
	}
}